package com.example.viewbinding

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.viewbinding.databinding.ActivitySecimBinding

class SecimActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySecimBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecimBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Siparis.setOnClickListener{
            val intent = Intent(this@SecimActivity,SonucActivity::class.java)
            intent.putExtra("veri",binding.KahveSec.getText().toString())
            if (binding.KahveSec.getText().toString() == "" || binding.KahveSec.getText().toString() == " "){
                Toast.makeText(applicationContext, "Select a coffee", Toast.LENGTH_LONG).show()
            }
            if (binding.KahveSec.getText().toString() == "Americano" || binding.KahveSec.getText().toString() == "Latte" ||
                binding.KahveSec.getText().toString() == "White Mocha" ||binding.KahveSec.getText().toString() == "Mocha" ||
                binding.KahveSec.getText().toString() == "Misto" || binding.KahveSec.getText().toString() == "Cappucino" ||
                binding.KahveSec.getText().toString() == "americano" || binding.KahveSec.getText().toString() == "latte" ||
                binding.KahveSec.getText().toString() == "white mocha" || binding.KahveSec.getText().toString() == "mocha" ||
                binding.KahveSec.getText().toString() == "misto" || binding.KahveSec.getText().toString() == "cappucino"){

                startActivity(intent)

            }
            else{
                Toast.makeText(applicationContext, "Select a valid coffee", Toast.LENGTH_LONG).show()
            }
        }
    }
}