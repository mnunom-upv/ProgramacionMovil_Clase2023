val asc = Array(5, { i -> (i * i).toString() })
TV1.append("Iterating Array elements: "+"\n")
for(s : String in asc){
    TV1.append(""+s+"\n")
}
TV1.append("Iterating Array elements: "+"\n")
for(s in asc){
    TV1.append(""+s+"\n")
}
// creates an Array<Int> of size 3 containing [1, 2, 3].
val a1 = arrayOf(1, 2, 3)
// creates an Array<Int> of size 3 containing [0, 2, 4]
val a2 = Array(3) { i -> i * 2 }
// creates an Array<Int?> of [null, null, null]
val a3 = arrayOfNulls<Int>(3)
TV1.append("Array of Ints: "+"\n")
TV1.append(Arrays.toString(a1)+"\n")
TV1.append("Array<Int> of size 3 containing [0, 2, 4]: "+"\n")
TV1.append(Arrays.toString(a2)+"\n")
TV1.append("Array<Int?> of [null, null, null]: "+"\n")
TV1.append(Arrays.toString(a3)+"\n")