val asc1 = Array(5, { i -> (i * i).toString() })
for(s : String in asc1){
    println(s);
}
for(s in asc1){
    println(s);
}
// creates an Array<Int> of size 3 containing [1, 2, 3].
val a1 = arrayOf(1, 2, 3) 
// creates an Array<Int> of size 3 containing [0, 2, 4]
val a2 = Array(3) { i -> i * 2 } 
// creates an Array<Int?> of [null, null, null]
val a3 = arrayOfNulls<Int>(3) 
TV1.append(Arrays.toString(a1)+"\n")
TV1.append(Arrays.toString(a2)+"\n")
TV1.append(Arrays.toString(a3)+"\n")