package upvictoria.pm_sep_dic_2023.iti_271086.ae4u1.macias_estrada

data class FilterItem(val icon:Int,val name: String)