package upvictoria.pm_sep_dic_2023.iti_271086.ae4u1.macias_estrada

import android.view.View

interface RecyclerviewCallbacks<T> {

    fun onItemClick(view: View, position: Int, item: T)

}