package upvictoria.pm_sep_dic_2023.iti_271086.ae4u1.macias_estrada

import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class AlertFilterAdapter(val context: Context) : RecyclerView.Adapter<AlertFilterAdapter.MyViewHolder>() {
    // List of the popup window's elements
    var filerList : List<FilterItem> = mutableListOf()

    private var selectedItem: Int = -1
    var callback: RecyclerviewCallbacks<FilterItem>? = null

    // Method to add elements to the filerList and notify to the adapter that the data has changed
    fun addAlertFilter(filers: List<FilterItem>) {
        filerList = filers.toMutableList()
        notifyDataSetChanged()
    }

    // Method to establish a new option selected and notify the data has changed
    fun selectedItem(position: Int){
        selectedItem = position
        notifyItemChanged(position)
    }

    // Method to link the elements of this view to the RecyclerView
    override fun onBindViewHolder(holder: MyViewHolder, p1: Int) {
        val item = filerList[p1]
        holder.tvName.text = item.name
        holder.alert_filter_icon.background = ContextCompat.getDrawable(context, item.icon)

        // if the element in this position match the selected element,
        // they swap their colors and then make the icon visible or not
        if(p1 == selectedItem) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                holder.alert_filter_icon.backgroundTintList = ContextCompat.getColorStateList(context, R.color.color_blue)
            }
            holder.tvName.setTextColor(ContextCompat.getColor(context,R.color.color_blue))
            holder.alert_filter_selected.visibility = View.VISIBLE
        } else {
            holder.alert_filter_selected.visibility = View.INVISIBLE
        }
    }

    fun setOnClick(click: RecyclerviewCallbacks<FilterItem>){
        callback = click
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): MyViewHolder {
        val view = LayoutInflater.from(p0.context).inflate(R.layout.alert_filter_item,p0,false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return filerList.size
    }

    // This class is used to maintain the references to the views within each element of the list.
    inner class MyViewHolder(item: View) : RecyclerView.ViewHolder(item) {

        var tvName:TextView = itemView.findViewById(R.id.alert_filter_name)
        var alert_filter_icon: ImageView = itemView.findViewById(R.id.alert_filter_icon)
        var alert_filter_selected: ImageView = itemView.findViewById(R.id.alert_filter_selected)
        var filterLayout: ConstraintLayout = itemView.findViewById(R.id.alert_filter_item_layout)
        init {
            setClickListener(filterLayout)
        }

        // When the item is clicked, the onItemClick method of the callback is called,
        // passing the position of the item and the FilterItem object.
        private fun setClickListener(view: View) {
            view.setOnClickListener {
                callback?.onItemClick(it, adapterPosition, filerList[adapterPosition])
            }
        }
    }

}