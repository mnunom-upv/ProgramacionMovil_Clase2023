package upvictoria.pm_sep_dic_2023.iti_271086.ae4u1.macias_estrada

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import upvictoria.pm_sep_dic_2023.iti_271086.ae4u1.macias_estrada.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private var filterPopup:PopupWindow? = null
    private var selectedItem: Int = -1 // index of the selected item
    private lateinit var binding: ActivityMainBinding // binding to detect all the main components by their ids

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater) // declaration of binding
        val view = binding.root
        setContentView(view)

        // optionMore button action
        binding.optionMore.setOnClickListener {
            dismissPopup()
            filterPopup = showAlertFilter()
            filterPopup?.isOutsideTouchable = true
            filterPopup?.isFocusable = true
            filterPopup?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            filterPopup?.showAsDropDown(binding.optionMore)
        }

        // filter button action
        binding.filter.setOnClickListener {
            dismissPopup()
            filterPopup = showAlertFilter()
            filterPopup?.isOutsideTouchable = true
            filterPopup?.isFocusable = true
            filterPopup?.showAsDropDown(binding.filter)
        }
    }

    override fun onStop() {
        super.onStop()
        dismissPopup()
    }

    // Quit popup window
    private fun dismissPopup() {
        filterPopup?.let {
            if(it.isShowing){
                it.dismiss()
            }
            filterPopup = null
        }

    }

    // Get the available options to show in the popup window
    private fun getFilterItems() : List<FilterItem> {

        val filterItemList = mutableListOf<FilterItem>()
        filterItemList.add(FilterItem(R.drawable.ic_desktop_mac_black_24dp,"Hotel"))
        filterItemList.add(FilterItem(R.drawable.ic_desktop_mac_black_24dp,"Rooms"))
        filterItemList.add(FilterItem(R.drawable.ic_desktop_mac_black_24dp,"Test Data One"))
        filterItemList.add(FilterItem(R.drawable.ic_desktop_mac_black_24dp,"Hotel Rooms"))

        return filterItemList
    }

    // show the popup window
    private fun showAlertFilter(): PopupWindow {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.alter_filter_layout, null)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.addItemDecoration(DividerItemDecoration(recyclerView.context, DividerItemDecoration.VERTICAL))
        val adapter = AlertFilterAdapter(this)

        // add the list of elements in the popup window
        adapter.addAlertFilter(getFilterItems())
        recyclerView.adapter = adapter
        adapter.selectedItem(selectedItem)

        // Manage the option to do when an option is touched
        adapter.setOnClick(object : RecyclerviewCallbacks<FilterItem> {
            override fun onItemClick(view: View, position: Int, item: FilterItem) {
                selectedItem = position
                Toast.makeText(this@MainActivity, "data = $item", Toast.LENGTH_SHORT).show()
                dismissPopup()
            }
        })

        // It returns the popup window based on the last view
        return PopupWindow(view, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
