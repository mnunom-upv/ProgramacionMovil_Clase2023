val empty = emptyArray<String>()
TV1.append("Empty array:"+"\n")
TV1.append(Arrays.toString(empty)+"\n")
var strings = Array<String>(size = 5, init = { index -> "Item #$index" })
TV1.append("Array with five elements:"+"\n")
TV1.append(Arrays.toString(strings)+"\n")
strings.set(2, "ChangedItem")
TV1.append("Array after change the third array element:"+"\n")
TV1.append(Arrays.toString(strings)+"\n")
TV1.append("Array Size: "+strings.size+"\n")
TV1.append("Read the third element:"+"\n")
TV1.append(""+strings[2]+"\n")
strings[2] = "RecentlyChangedItem_"
TV1.append("Array after change the third array element (again):"+"\n")
TV1.append(""+strings[2]+"\n")



    