package com.example.countdowntimer;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

// La actividad MainActivity extiende Activity e implementa la interfaz OnClickListener para manejar los eventos de clic.
public class MainActivity extends Activity implements OnClickListener {
    // Se definen las variables de instancia
    private CountDownTimer countDownTimer; // Para el temporizador
    private boolean timerHasStarted = false; // Para rastrear si el temporizador se ha iniciado
    private Button startB; // Para el botón
    public TextView text; // text para el TextView

    // Constantes para el tiempo inicial y el intervalo
    private final long startTime = 30 * 1000;
    private final long interval = 1 * 1000;


    @Override
    public void onCreate(Bundle savedInstanceState) { // se crea el diseño desde activity_main.xml
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialización de elementos de la interfaz
        startB = (Button) this.findViewById(R.id.button);
        startB.setOnClickListener(this);
        text = (TextView) this.findViewById(R.id.timer);
        countDownTimer = new MyCountDownTimer(startTime, interval);
        text.setText(text.getText() + String.valueOf(startTime/1000));
    }

    // Clase interna que representa un temporizador de cuenta regresiva
    public class MyCountDownTimer extends CountDownTimer { // Se utiliza para definir las acciones que ocurren en cada tick (cada segundo)
                                                            // y cuando el temporizador finaliza.
        public MyCountDownTimer(long startTime, long interval) {
            super(startTime, interval);
        }
        @Override
        public void onFinish() {
            text.setText("Time's up!");
        }
        @Override
        public void onTick(long millisUntilFinished) {
            text.setText("" + millisUntilFinished/1000);
        }
    }
    @Override
    public void onClick(View v) { // En este metodo, se manejan los eventos del botón
        if (!timerHasStarted) {
            // Inicia el temporizador
            countDownTimer.start();
            timerHasStarted = true;
            startB.setText("STOP");
        } else {
            // Detiene el temporizador
            countDownTimer.cancel();
            timerHasStarted = false;
            startB.setText("RESTART");
        }
    }
}
