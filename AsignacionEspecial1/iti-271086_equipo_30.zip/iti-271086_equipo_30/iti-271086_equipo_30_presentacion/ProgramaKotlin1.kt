val ints = intArrayOf(1, 4)
TV1.append("Array of ints: \n")
TV1.append(Arrays.toString(ints)+"\n")
TV1.append("Average of integer array: "+ints.average()+"\n")
TV1.append("First Array component: "+ints.component1()+"\n")
TV1.append("Access item with index 1: "+ints.get(1)+"\n")
TV1.append("Return null if out of bound: "+ints.getOrNull(2)+"\n")

val doubles = doubleArrayOf(1.5, 3.0, 9.5, 12.5, 17.4, 0.75, 7.4)
TV1.append("Array of doubles: \n")
TV1.append(Arrays.toString(doubles)+"\n")
TV1.append("Average of doubles array: "+doubles.average()+"\n")
TV1.append("First element of array: "+doubles.first()+"\n")
TV1.append("Last element of array: "+doubles.last()+"\n")
TV1.append("Sorted array (copy): "+
    Arrays.toString(doubles.sortedArray())+"\n")
TV1.append("Original array: "+
    Arrays.toString(doubles)+"\n")
doubles.sort()
TV1.append("Sorted array after sorting: "+Arrays.toString(doubles)+"\n")
TV1.append("Minimum array value: "+ doubles.minOrNull().toString()+"\n")
TV1.append("Maximum array value: "+ doubles.maxOrNull().toString()+"\n")

