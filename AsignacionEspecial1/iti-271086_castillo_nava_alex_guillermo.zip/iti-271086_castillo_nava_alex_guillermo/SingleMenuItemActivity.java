package com.upvictoria.pm_sep_dic_2023.iti_271086_castillo_nava.androidxmlparsing;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SingleMenuItemActivity extends Activity {

    static final String KEY_NAME = "name";
    static final String KEY_DESC = "description";
    static final String KEY_COST = "cost";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_list_item);

        Intent in = getIntent();
        String name = in.getStringExtra(KEY_NAME);
        String description = in.getStringExtra(KEY_DESC);
        String cost = in.getStringExtra(KEY_COST);

        TextView lblName = findViewById(R.id.name_label);
        TextView lblDesc = findViewById(R.id.description_label);
        TextView lblCost = findViewById(R.id.cost_label);

        lblName.setText(name);
        lblCost.setText(cost);
        lblDesc.setText(description);
    }
}
