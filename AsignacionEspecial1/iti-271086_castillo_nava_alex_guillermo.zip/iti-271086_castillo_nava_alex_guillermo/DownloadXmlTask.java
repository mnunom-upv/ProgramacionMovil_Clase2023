package com.upvictoria.pm_sep_dic_2023.iti_271086_castillo_nava.androidxmlparsing;

import android.os.AsyncTask;
import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class DownloadXmlTask extends AsyncTask<String, Void, ArrayList<HashMap<String, String>>> {
    private static final String TAG = "DownloadXmlTask";

    @Override
    protected ArrayList<HashMap<String, String>> doInBackground(String... urls) {
        ArrayList<HashMap<String, String>> menuItems = new ArrayList<HashMap<String, String>>();
        XMLParser parser = new XMLParser();
        String xml = parser.getXmlFromUrl(urls[0]); // getting XML
        Document doc = parser.getDomElement(xml);
        String KEY_ITEM = "item";
        String KEY_NAME = "title";
        String KEY_COST = "link";
        String KEY_DESC = "description";

        NodeList nl = doc.getElementsByTagName(KEY_ITEM);
        // looping through all item nodes <item>
        for (int i = 0; i < nl.getLength(); i++) {
            // creating a new HashMap
            HashMap<String, String> map = new HashMap<String, String>();
            Element e = (Element) nl.item(i);
            map.put(KEY_NAME, parser.getValue(e, KEY_NAME));
            Log.d("TITLE", parser.getValue(e, KEY_NAME));
            map.put(KEY_COST, "Rs." + parser.getValue(e, KEY_COST));
            map.put(KEY_DESC, parser.getValue(e, KEY_DESC));

            // adding HashList to ArrayList
            menuItems.add(map);
        }

        return menuItems;
    }


    @Override
    protected void onPostExecute(ArrayList<HashMap<String, String>> result) {
        // The parsing is complete, and the data is available in 'result'.
        // You can now update the UI with the parsed data if needed.
    }
}
