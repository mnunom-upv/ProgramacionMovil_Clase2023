package com.upvictoria.pm_sep_dic_2023.iti_271086_castillo_nava.androidxmlparsing;

/*
no se si el package deba llevar mendigo ae1 o ir como toda aplicacion
package com.upvictoria.pm_sep_dic_2023.iti_271086.ae1.pi1u1.castillo_nava.androidxmlparsing;
*/
import android.app.ListActivity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.HashMap;

public class AndroidXMLParsing extends ListActivity {

    // All static variables
    static final String URL = "http://feeds.feedburner.com/dinamalar/Front_page_news?format=xml";
    // XML node keys
    static final String KEY_ITEM = "item";
    static final String KEY_NAME = "title";
    static final String KEY_COST = "link";
    static final String KEY_DESC = "description";

    ArrayList<HashMap<String, String>> menuItems;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        menuItems = new ArrayList<>();
        new DownloadXmlTask().execute(URL);
    }

    private class DownloadXmlTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... urls) {
            XMLParser parser = new XMLParser();
            String xml = parser.getXmlFromUrl(urls[0]);
            Document doc = parser.getDomElement(xml);

            NodeList nl = doc.getElementsByTagName(KEY_ITEM);
            for (int i = 0; i < nl.getLength(); i++) {
                HashMap<String, String> map = new HashMap<>();
                Element e = (Element) nl.item(i);
                map.put(KEY_NAME, parser.getValue(e, KEY_NAME));
                map.put(KEY_COST, "Rs." + parser.getValue(e, KEY_COST));
                map.put(KEY_DESC, parser.getValue(e, KEY_DESC));
                menuItems.add(map);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            ListAdapter adapter = new SimpleAdapter(AndroidXMLParsing.this, menuItems, R.layout.list_item,
                    new String[] { KEY_NAME, KEY_DESC, KEY_COST }, new int[] {
                    R.id.name, R.id.description, R.id.cost });
            setListAdapter(adapter);
        }
    }
}
