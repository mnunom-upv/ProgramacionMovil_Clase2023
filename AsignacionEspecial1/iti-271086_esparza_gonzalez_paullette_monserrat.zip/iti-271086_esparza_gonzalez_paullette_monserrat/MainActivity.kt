package upvvictoria.pm_sep_dic_2023.iti_271086.ae1u1.esparza_gonzalez

import Movie
import android.R
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.AdapterView.OnItemClickListener
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import upvvictoria.pm_sep_dic_2023.iti_271086.ae1u1.esparza_gonzalez.databinding.ActivityMainBinding
import kotlinx.coroutines.*

// MainActivity es la actividad principal de la aplicación y es donde se inicializa y se configura
// la mayoría de la funcionalidad de la aplicación.
class MainActivity : AppCompatActivity() {

    // Referencia a los objetos de binding y adapter que se utilizarán en esta actividad.
    lateinit var binding: ActivityMainBinding
    lateinit var autoSuggestAdapter: AutoSuggestAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configura el adapter para el AutoCompleteTextView.
        autoSuggestAdapter = AutoSuggestAdapter(this, R.layout.simple_dropdown_item_1line)
        binding.autoComplete.setThreshold(2)  // Establece el número mínimo de caracteres para mostrar sugerencias.
        binding.autoComplete.setAdapter(autoSuggestAdapter)
        // Configura el listener para los elementos clickeados en las sugerencias.
        binding.autoComplete.onItemClickListener = OnItemClickListener { parent, view, position, id ->
            Toast.makeText(this, autoSuggestAdapter.getObject(position), Toast.LENGTH_SHORT).show()
        }
        // Agrega un TextWatcher al AutoCompleteTextView para escuchar los cambios en el texto.
        binding.autoComplete.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val count = binding.autoComplete.text.toString().length
                // Si el texto ingresado tiene más de 2 caracteres, realiza una llamada a la API.
                if (count > 2) {
                    doApiCall()
                }
            }
            override fun afterTextChanged(s: Editable) {}
        })
    }

    // Método para realizar la llamada a la API y obtener las sugerencias de películas.
    fun doApiCall() {
        val searchTerm = binding.autoComplete.text.toString()  // Obtiene el texto ingresado.
        // Lanza una coroutine en el hilo IO para realizar la llamada a la API.
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Realiza la llamada a la API.
                val apiCall = RetrofitService.getInstance().getAllMovies(searchTerm, "6ca248d2")
                if (apiCall.isSuccessful) {
                    // Si la llamada es exitosa, actualiza las sugerencias en el hilo principal.
                    withContext(Dispatchers.Main) {
                        val response = apiCall.body()
                        updateAutoComplete(response?.Search)
                    }
                } else {
                    // Si hay un error, loguea el error.
                    Log.e("API_ERROR", "Error: ${apiCall.errorBody()?.string()}")
                }
            } catch (e: Exception) {
                // Si hay una excepción, loguea la excepción.
                Log.e("NETWORK_ERROR", "Exception: ${e.message}")
            }
        }
    }

    // Método para actualizar las sugerencias basadas en la respuesta de la API.
    private fun updateAutoComplete(body: List<Movie>?) {
        body?.let {
            val list = it.map { it.title }  // Mapea la lista de películas a una lista de títulos.
            autoSuggestAdapter.setData(list)  // Actualiza los datos del adapter.
            autoSuggestAdapter.notifyDataSetChanged()  // Notifica al adapter que los datos han cambiado.
        }
    }
}
