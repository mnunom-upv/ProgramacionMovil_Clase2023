package upvvictoria.pm_sep_dic_2023.iti_271086.ae1u1.esparza_gonzalez

import Movie
import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

// Interfaz que define los url de la API que serán utilizados por Retrofit.
interface RetrofitService {

    // Define los url para obtener todas las películas basadas en un término de búsqueda y una clave API.
    @GET("/")
    suspend fun getAllMovies(@Query("s") searchTerm: String, @Query("apikey") apiKey: String): Response<MovieResponse>

    // Objeto companion que contiene la lógica para obtener una instancia de RetrofitService.
    companion object {

        // Variable que almacena una instancia de RetrofitService para reutilizarla.
        var retrofitService: RetrofitService? = null

        // Método que proporciona una instancia de RetrofitService, creándola si es necesario.
        fun getInstance() : RetrofitService {

            // Verifica si ya existe una instancia de RetrofitService; si no, la crea.
            if (retrofitService == null) {

                // Configura el interceptor de logging para registrar las solicitudes y respuestas de la API.
                val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }

                // Crea un cliente OkHttpClient y añade el interceptor de logging.
                val client = OkHttpClient.Builder()
                    .addInterceptor(logging)
                    .build()

                // Crea una instancia de Retrofit con la URL base de la API y el cliente OkHttpClient.
                val retrofit = Retrofit.Builder()
                    .client(client)
                    .baseUrl("https://www.omdbapi.com/")
                    .addConverterFactory(GsonConverterFactory.create())  // Añade el convertidor de Gson para manejar las respuestas JSON.
                    .build()

                // Crea una instancia de RetrofitService a partir de la instancia de Retrofit.
                retrofitService = retrofit.create(RetrofitService::class.java)

            }

            // Retorna la instancia de RetrofitService.
            return retrofitService!!
        }
    }
}

// Clase que modela la respuesta de la API, conteniendo una lista de películas.
data class MovieResponse(val Search: List<Movie>)
