package upvvictoria.pm_sep_dic_2023.iti_271086.ae1u1.esparza_gonzalez

import android.content.Context
import android.widget.ArrayAdapter
import android.widget.Filter
import android.widget.Filterable
import java.util.ArrayList

// Esta clase implementa la interfaz Filterable para proporcionar
// sugerencias de autocompletado personalizadas basadas en la entrada del usuario.
class AutoSuggestAdapter(context: Context, resource: Int) : ArrayAdapter<String?>(context, resource), Filterable {

    // Lista que contiene los datos que se mostrarán en las sugerencias de autocompletado.
    private var mlistData = mutableListOf<String>()

    // Método para actualizar los datos que se mostrarán en las sugerencias de autocompletado.
    fun setData(list: List<String>?) {
        mlistData.clear()  // Limpia la lista actual
        mlistData.addAll(list!!)  // Añade todos los elementos de la nueva lista
    }

    // Retorna el número de elementos en la lista de datos.
    override fun getCount(): Int {
        return mlistData.size
    }

    // Retorna el elemento en la posición especificada en la lista de datos.
    override fun getItem(position: Int): String? {
        return mlistData[position]
    }

    // Método adicional para obtener el objeto completo directamente del adaptador.
    fun getObject(position: Int): String {
        return mlistData[position]
    }

    // Proporciona el objeto Filter que se utilizará para filtrar las sugerencias de autocompletado
    // basadas en la entrada del usuario.
    override fun getFilter(): Filter {
        return object : Filter() {

            // Este método se llama cuando el filtro está siendo procesado.
            override fun performFiltering(constraint: CharSequence?): FilterResults? {
                val filterResults = FilterResults()
                if (constraint != null) {
                    // Si hay un término de búsqueda, configura los resultados del filtro
                    // para que contengan la lista completa de datos.
                    filterResults.values = mlistData
                    filterResults.count = mlistData.size
                }
                return filterResults
            }

            // Este método se llama después de que se completó el filtrado.
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                if (results != null && results.count > 0) {
                    // Si hay resultados, notifica al adaptador que los datos han cambiado,
                    // lo que causa que la UI se actualice.
                    notifyDataSetChanged()
                } else {
                    // Si no hay resultados, notifica al adaptador que los datos no son válidos,
                    // lo que causa que la UI se limpie.
                    notifyDataSetInvalidated()
                }
            }
        }
    }

    // Inicializa la lista de datos como un ArrayList vacío.
    init {
        mlistData = ArrayList()
    }
}
