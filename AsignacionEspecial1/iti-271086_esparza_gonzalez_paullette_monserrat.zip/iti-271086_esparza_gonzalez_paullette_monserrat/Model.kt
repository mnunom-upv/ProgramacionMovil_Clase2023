import com.google.gson.annotations.SerializedName
//Clase de la pelicula
data class Movie(
    @SerializedName("Title") val title: String,
    @SerializedName("Poster") val poster: String,
    @SerializedName("Type") val type: String
)