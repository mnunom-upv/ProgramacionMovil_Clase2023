package com.upvictoria.pm_sep_dic_2023.iti_271086.castillo_nava.expendablerecyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.mindorks.placeholderview.ExpandablePlaceHolderView;
import com.mindorks.placeholderview.annotations.Resolve;

// Vista para cada elemento hijo (película) en la vista expandible
public class ChildView {

    private TextView textViewChild;
    private ImageView childImage;
    private Context mContext;
    private Movie movie;

    // Constructor para inicializar la vista del elemento hijo
    public ChildView(Context mContext, Movie movie) {
        this.mContext = mContext;
        this.movie = movie;
    }

    // Método de resolución para configurar la vista
    @Resolve
    private void onResolve() {
        // Inicializar vistas
        ExpandablePlaceHolderView rootView = new ExpandablePlaceHolderView(mContext);
        View view = LayoutInflater.from(mContext).inflate(R.layout.child_layout, rootView, true);
        textViewChild = view.findViewById(R.id.child_name);
        childImage = view.findViewById(R.id.child_image);

        // Establecer datos en las vistas
        if (textViewChild != null && childImage != null && movie != null) {
            textViewChild.setText(movie.getName());
            Glide.with(mContext).load(movie.getImageUrl()).into(childImage);
            textViewChild.setOnClickListener(v -> {
                if (movie != null) {
                    Toast.makeText(mContext, movie.getName(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
