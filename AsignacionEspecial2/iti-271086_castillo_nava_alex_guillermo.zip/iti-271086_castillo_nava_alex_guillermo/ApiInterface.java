package com.upvictoria.pm_sep_dic_2023.iti_271086.castillo_nava.expendablerecyclerview;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;

// Interfaz para definir los métodos de la API
public interface ApiInterface {

    // Método GET para obtener todos los datos de la lista de películas
    @GET("movielist.json")
    Call<List<Movie>> getAllMovies();
}
