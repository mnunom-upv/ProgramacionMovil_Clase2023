package com.upvictoria.pm_sep_dic_2023.iti_271086.castillo_nava.expendablerecyclerview;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    private static Retrofit retrofit; // Objeto Retrofit para la API
    private static String BASE_URL="https://howtodoandroid.com/movielist.json"; // URL base de la API

    // Método para obtener una instancia de Retrofit
    public static Retrofit getInstance(){
        // Verificar si la instancia de Retrofit no ha sido creada
        if(retrofit == null){
            // Crear una nueva instancia de Retrofit con la URL base y el convertidor Gson
            retrofit = new Retrofit.Builder().baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        // Devolver la instancia de Retrofit
        return retrofit;
    }
}
