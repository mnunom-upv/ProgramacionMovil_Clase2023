package com.upvictoria.pm_sep_dic_2023.iti_271086.castillo_nava.expendablerecyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.mindorks.placeholderview.ExpandablePlaceHolderView;
import com.mindorks.placeholderview.annotations.Resolve;

// Vista para cada encabezado en la vista expandible
public class HeaderView {

    private TextView headerText;
    private Context mContext;
    private String mHeaderText;

    // Constructor para inicializar la vista del encabezado
    public HeaderView(Context context, String headerText) {
        this.mContext = context;
        this.mHeaderText = headerText;
    }

    // Método de resolución para configurar la vista
    @Resolve
    private void onResolve() {
        // Inicializar vistas
        ExpandablePlaceHolderView rootView = new ExpandablePlaceHolderView(mContext);
        View view = LayoutInflater.from(mContext).inflate(R.layout.header_layout, rootView, false);
        rootView.addView(view);
        headerText = view.findViewById(R.id.header_text);

        // Establecer texto en headerText
        if (headerText != null) {
            headerText.setText(mHeaderText);
            headerText.setOnClickListener(v -> {
                Toast.makeText(mContext, "Clicked: " + mHeaderText, Toast.LENGTH_SHORT).show();
            });
        }
    }
}
