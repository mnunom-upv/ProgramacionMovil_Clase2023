package com.upvictoria.pm_sep_dic_2023.iti_271086.castillo_nava.expendablerecyclerview;

import com.google.gson.annotations.SerializedName;

// Clase que representa un objeto de película

public class Movie {

    // Atributos de la película
    @SerializedName("name")
    private String name;
    @SerializedName("desc")
    private String desc;
    @SerializedName("imageUrl")
    private String imageUrl;
    @SerializedName("category")
    private String categoty;

    // Constructor de la película
    public Movie(String name, String desc, String imageUrl, String categoty) {
        this.name = name;
        this.desc = desc;
        this.imageUrl = imageUrl;
        this.categoty = categoty;
    }

    // Métodos getter y setter para los atributos
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getCategoty() {
        return categoty;
    }

    public void setCategoty(String categoty) {
        this.categoty = categoty;
    }

    // toString para representación de cadena
    @Override
    public String toString() {
        return "Movie{" +
                "name='" + name + '\'' +
                ", desc='" + desc + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", categoty='" + categoty + '\'' +
                '}';
    }
}