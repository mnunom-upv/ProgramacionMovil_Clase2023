package com.upvictoria.pm_sep_dic_2023.iti_271086.castillo_nava.expendablerecyclerview;

import android.os.Bundle;
import android.util.Log;
import android.view.View.OnClickListener;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.mindorks.placeholderview.ExpandablePlaceHolderView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private Map<String,List<Movie>> categoryMap; // Mapa que almacena películas por categoría
    private List<Movie> movieList; // Lista de películas
    private ExpandablePlaceHolderView expandablePlaceHolderView; // Vista expandible para mostrar películas

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialización de variables
        movieList = new ArrayList<>();
        categoryMap = new HashMap<>();
        expandablePlaceHolderView = findViewById(R.id.expandablePlaceHolder);

        // Carga de datos
        loadData();

        // Listener para clics en la vista expandible
        expandablePlaceHolderView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                Toast.makeText(getApplicationContext(), "Clicked", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Método para cargar datos desde la API
    private void loadData(){
        ApiInterface apiInterface = ApiClient.getInstance().create(ApiInterface.class);
        apiInterface.getAllMovies().enqueue(new Callback<List<Movie>>() {
            @Override
            public void onResponse(Call<List<Movie>> call, Response<List<Movie>> response) {
                // Al recibir la respuesta, se actualiza la lista de películas y se prepara la vista
                movieList = response.body();
                getHeaderAndChild(movieList);
            }

            @Override
            public void onFailure(Call<List<Movie>> call, Throwable t) {
                // Manejo de errores en la carga de datos
            }
        });
    }

    // Método para preparar la vista con encabezados y elementos secundarios (películas)
    private void getHeaderAndChild(List<Movie> movieList) {
        for (Movie movie : movieList) {
            // Agrupar películas por categoría en el mapa
            List<Movie> movieList1 = categoryMap.get(movie.getCategoty());
            if (movieList1 == null) {
                movieList1 = new ArrayList<>();
            }
            movieList1.add(movie);
            categoryMap.put(movie.getCategoty(), movieList1);
        }

        Log.d("Map", categoryMap.toString());

        // Recorrer el mapa para mostrar encabezados y películas correspondientes
        Iterator<Map.Entry<String, List<Movie>>> it = categoryMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, List<Movie>> pair = it.next();
            Log.d("Key", pair.getKey());
            expandablePlaceHolderView.addView(new HeaderView(this, pair.getKey())); // Agregar encabezado

            // Agregar películas asociadas a cada encabezado
            List<Movie> movieList1 = pair.getValue();
            if (movieList1 != null) {
                for (Movie movie : movieList1) {
                    expandablePlaceHolderView.addView(new ChildView(this, movie)); // Agregar elemento secundario (película)
                }
            }
            it.remove();
        }
    }
}
