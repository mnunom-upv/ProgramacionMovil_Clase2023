package upvictoria.pm_sep_dic_2023.iti_271086.ae14u2.macias_estrada;

public class Product {

    private String pName;
    private int pImage;
    private String pOffer;

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public int getpImage() {
        return pImage;
    }

    public void setpImage(int pImage) {
        this.pImage = pImage;
    }

    public String getpOffer() {
        return pOffer;
    }

    public void setpOffer(String pOffer) {
        this.pOffer = pOffer;
    }


}
