package com.example.kotlincoroutines

data class Movie(val category: String, val imageUrl: String, val name: String, val desc: String)