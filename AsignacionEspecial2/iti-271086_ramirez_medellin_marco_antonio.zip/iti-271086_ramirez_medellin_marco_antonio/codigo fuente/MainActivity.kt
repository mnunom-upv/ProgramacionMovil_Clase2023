package com.example.kotlincoroutines

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.kotlincoroutines.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    private val mainViewModel: MainViewModel by viewModels()
    lateinit var adapter: DashboardMenuAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = DashboardMenuAdapter()
        binding.recyclerview.adapter = adapter

        mainViewModel.movieList.observe(this) {
            // Actualizar el adaptador con la nueva lista de películas
            adapter.addMovieList(it)
        }

        binding.recyclerview.visibility = View.VISIBLE

        binding.startPrint.setOnClickListener {
            // Llamar a la función para obtener la lista de películas y mostrarlas
            mainViewModel.startPrintWithTimeout()
        }

        binding.stopPrint.setOnClickListener {
            mainViewModel.stopPrint()
        }
    }
}



